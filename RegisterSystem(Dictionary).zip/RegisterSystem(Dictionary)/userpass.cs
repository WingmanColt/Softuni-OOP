using System;

    public class userpass
    {

        private string user_pass;
        public string PASS
        {
            get { return user_pass;}
            set { user_pass = value;}
        }
        
   public override string ToString()
    {
        return " Password: " + user_pass;
    }
    }