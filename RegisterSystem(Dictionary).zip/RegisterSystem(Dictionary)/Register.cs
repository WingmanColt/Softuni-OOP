﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

class Program
    {
        static void Main(string[] args)
        {
        var dictionary = new Dictionary<userid, userpass>();

        userid person_id = new userid { ID = Console.ReadLine()};
        userpass person_pass = new userpass {PASS = Console.ReadLine()};

        dictionary.Add(person_id, person_pass);
        Console.WriteLine(string.Join(",", dictionary.Keys));
        Console.WriteLine(string.Join(",", dictionary.Values));

   using (var writer = new StreamWriter(@"/home/petroff/Projects/data.csv"))
   {
        foreach (var pair in dictionary) 
        {
        writer.WriteLine("{0};{1};", pair.Key, pair.Value);
        }
    }
        }
    }

