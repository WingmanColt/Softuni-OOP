using System;
using System.Collections.Generic;
using System.IO;

namespace Core
{
public class Engine
{
private static bool isUserLogged = false;

   public static bool Logged
   { 
        get { return isUserLogged; }
        set { isUserLogged = value; }

   }
}
}