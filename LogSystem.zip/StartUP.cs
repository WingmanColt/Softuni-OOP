﻿using System;

namespace Projects
{
    class StartUP : LogCore
    {
        static void Main(string[] args)
        {
            LogCore logs = new LogCore();

            Console.WriteLine("Type 'Console' or 'File'");
            logs.MyTypes = Console.ReadLine();

            logs.LogOutput(Level.Critical, "Program not responded!");
            logs.LogOutput(Level.Error, "No internet connection");
            logs.LogOutput(Level.Info, "Test");
        }
    }
}
