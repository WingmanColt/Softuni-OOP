﻿using System;
using System.Globalization;

namespace Projects
{
    class LogCore
    {   
    // Consts
    const string DIR = "Logs.txt";
    public enum Level {Info, Warn, Error, Critical, Fatal}; 

    DateTime localDate = DateTime.Now;

    public string myType;
    public string MyTypes
    {
        get { return myType;}
        set { myType = value;}
    }

    
    public void LogOutput(Level warn, string message)
    {
        var ShowOutput = $"{localDate} - {warn} - {message}";
        switch(this.myType)
        {
        case "File":
        {
        using (System.IO.StreamWriter file = new System.IO.StreamWriter(DIR, true))
        file.WriteLine(ShowOutput);
        } break;

        case "Console": Console.WriteLine(ShowOutput);
        break;

    }

}
    }
}