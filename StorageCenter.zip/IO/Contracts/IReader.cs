﻿namespace StorageMaster.IO.Contracts
{
	public interface IReader
	{
		string ReadLine();
	}
}
