﻿namespace StorageMaster.IO.Contracts
{
	public interface IWriter
	{
		void WriteLine(string message);
	}
}
