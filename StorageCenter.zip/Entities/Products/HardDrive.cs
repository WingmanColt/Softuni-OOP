﻿namespace StorageMaster.Entities.Products
{

    public class HardDrive : Product
    {
        public HardDrive(double price)
            : base(price: price, weight: 1.0)
        {
        }

    }
}