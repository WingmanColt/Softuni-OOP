﻿namespace StorageMaster.Entities.Products
{

    public class Gpu : Product
    {
        public Gpu(double price)
            : base(price: price, weight: 0.7)
        {
        }

    }
}