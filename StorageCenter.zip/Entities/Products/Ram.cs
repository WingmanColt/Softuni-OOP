﻿namespace StorageMaster.Entities.Products
{

    public class Ram : Product
    {
        public Ram(double price)
            : base(price: price, weight: 0.1)
        {
        }

    }
}