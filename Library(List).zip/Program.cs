﻿using System;
using System.Collections.Generic;

namespace Projects
{
    class Program
    {
        static void Main(string[] args)
        {
            Book bookOne = new Book("Koll", 1883, "George");
            Book bookTwo = new Book("Kollegah", 1885, "George", "Washington");
            
            Library libraryOne = new Library();
            Library libraryTwo = new Library(bookOne, bookTwo);
        }
    }
}
