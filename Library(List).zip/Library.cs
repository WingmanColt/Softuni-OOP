﻿using System;
using System.Collections.Generic;

namespace Projects
{
   public class Library
    {
        private List<Book> books;

        public Library(params Book[] books)
        {
            this.books = new List<Book>(books);
        }
    }
}
