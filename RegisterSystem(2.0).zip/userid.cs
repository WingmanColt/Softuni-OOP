using System;

public class userid {
    private string user_id;
    public string ID {
        get { return user_id; }
        set { user_id = value; }
    }

    public override string ToString () {
        return user_id;
    }

}