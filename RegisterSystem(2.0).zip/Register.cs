using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

class Program 
{
    const string FILE_DIR = "/home/petroff/Projects/data.csv";

    static void Main (string[] args) 
    {
        var dictionary = new Dictionary<userid, userpass> ();
        var ShowAllUsers = false;
        var isUserLogged = false;
        string input;

    Console.WriteLine("Welcome to Register System by iNexus !");
    Console.WriteLine("Type 'REGISTER' or 'LOGIN' ...");
    switch ((input = Console.ReadLine()))
    {
        case "REGISTER":
        {
         Console.WriteLine("Press enter to continue login...");
         Console.WriteLine("Type 'SHOW' to see all users in list...");
         Console.WriteLine("Type 'END' to exit from register systeM...");
        if((input = Console.ReadLine()) == "SHOW")
        {
        ShowAllUsers = true;
        Console.WriteLine("Show all users list is Activated !!!");
        }
        else ShowAllUsers = false;
       
        while ((input = Console.ReadLine()) != "END")
        {
            Console.WriteLine("Enter Username: ");
            userid person_id = new userid { ID = Console.ReadLine()};

            Console.WriteLine("Enter Password: ");
            userpass person_pass = new userpass { PASS = Console.ReadLine()};

            if(input != "END")
            {
            dictionary.Add(person_id, person_pass);

            if(!ShowAllUsers)
            Console.WriteLine(string.Join (",", person_id) + " saved with LOGI" + string.Join(",", person_pass));
            SaveData(dictionary, ShowAllUsers);
            }
        }
    } break;

case "LOGIN":
{
    if(isUserLogged)
    {
       Console.WriteLine("You are already logged in system !"); 
       return;
    }else{
    Console.WriteLine("Press enter to continue login...");
    
            while ((input = Console.ReadLine()) != "END")
            {
            var lines  = File.ReadLines(@FILE_DIR);
            foreach (var line in lines)
            {
                var res = line.Split(new char[] {';'});

                Console.WriteLine("Username: ");

                if (res[0] ==  Console.ReadLine())
                {                        
                Console.WriteLine("Password: ");
 
                if (res[1] == Console.ReadLine())
                {
                isUserLogged = true;
                Console.WriteLine("You are logged in System !");  
                return;
                } else {
                Console.WriteLine("Wrong password !");  
                return;
                }

                }else{
                 Console.WriteLine("Wrong username !");
                return;
                }
            }
       }          
   }     
} break;

}   
}    

    private static void SaveData(Dictionary<userid, userpass> dictionary, bool all)
    {
        using (var writer = new StreamWriter(@FILE_DIR))
        {
            foreach (var pair in dictionary)
            {
                writer.WriteLine("{0};{1}", pair.Key, pair.Value);

                if(all)
                Console.WriteLine(string.Join(",", dictionary.Keys) + " saved with" + string.Join(",", dictionary.Values) );
            }
        }
    }
}


