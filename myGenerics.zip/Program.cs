﻿using System;

    class Program 
    {
        static void Main(string[] args)
        {
            CustomList<string> list = new CustomList<string>();
           /* 
            for (int i = 0; i < 25; i++)
            {
                list.Add(i);
                Console.WriteLine(i);
            }

            Console.WriteLine("|||||||||||||||||||||||||||||||||||||||||");

            for (int i = 0; i < 16; i++)
            {
                list.Remove(i);
                Console.WriteLine(i);
            }

            */

            string input;
            while ((input = Console.ReadLine()) != "END")
            {
                string[] commandArgs = input.Split();
                string command = commandArgs[0];

                switch (command)
                {
                    case "Add": list.Add(commandArgs[1]);
                    break;

                    case "Sort":list.Sort();
                    break;  

                    case "Remove": 
                    {
                    int index = int.Parse(commandArgs[1]);
                    list.Remove(index);
                    }break;

                    case "Contains": 
                    {
                    bool listContains = list.Contains(commandArgs[1]);
                    Console.WriteLine(listContains);
                    }break;

                    case "Swap": 
                    {
                    int index1 = int.Parse(commandArgs[1]);
                    int index2 = int.Parse(commandArgs[2]);
                    list.Swap(index1, index2);
                    }break;

                    case "Greater": 
                    {
                    int count = list.CountGreaterThan(commandArgs[1]);
                    Console.WriteLine(count);
                    }break;

                    case "Min": 
                    {
                    string minE = list.Min();
                    Console.WriteLine(minE);
                    }break;

                    case "Max": 
                    {
                    string maxE = list.Max();
                    Console.WriteLine(maxE);
                    }break;        

                    case "Print": 
                    {
                     for (int i = 0; i < list.Count; i++)
                     {
                         Console.WriteLine(list[i]);
                     }
                    }break;   
                                  
                }
            }
        }
    }
