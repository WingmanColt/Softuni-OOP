﻿using AnimalSystem.AnimalsCategory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalSystem.Animals
{
    class Startup
    {
        static void Main(string[] args)
        {
            var listofAnimals = new List<Animal>();

            listofAnimals.Add(new Cat());
            listofAnimals.Add(new Dog());

            foreach (var animal in listofAnimals)
            {
                Console.WriteLine(animal.SayHello());
            }
        }
    }
}
