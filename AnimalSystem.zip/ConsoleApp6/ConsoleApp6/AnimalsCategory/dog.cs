﻿
namespace AnimalSystem.AnimalsCategory
{
    public class Dog:Animal
    {
        public override string SayHello()
        {
            return base.SayHello() + "Dog";
        }
    }
}
