﻿
namespace AnimalSystem.AnimalsCategory
{
   public class Cat:Animal
    {
        public override string SayHello()
        {
            return base.SayHello() + "Cat";
        }

    }
}
