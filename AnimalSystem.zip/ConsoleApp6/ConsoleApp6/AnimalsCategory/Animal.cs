﻿
namespace AnimalSystem.AnimalsCategory
{
    public abstract class Animal
    {
        public string Name { get; set; }
        public string Color { get; set; }


        // AKO IMA POVECHE CODE, TOVA E PO-DOBRIQ METOD
        public virtual string SayHello()
        {
            return "HI I am animal: ";
        }

    }
}
