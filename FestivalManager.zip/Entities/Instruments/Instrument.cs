﻿using System;

namespace FestivalManager.Entities.Instruments
{
	using Contracts;

	public abstract class Instrument : IInstrument
	{
		private double wear;
		private const int MaxWear = 100;

		protected Instrument()
		{
			this.Wear = MaxWear;
		    this.IsBroken = false;
		}

		public double Wear
		{
			get
			{
				return this.wear;
			}
			private set
			{
				this.wear = Math.Min(Math.Max(value, 0), 100);

			    if (this.wear == 0)
			    {
			        this.IsBroken = true;
			    }

			    if (this.wear > 0)
			    {
			        this.IsBroken = false;
			    }
			}
		}

		protected abstract int RepairAmount { get; }

		public void Repair() => this.Wear += this.RepairAmount;

		public void WearDown() => this.Wear -= this.RepairAmount;

		public bool IsBroken { get; private set; }


        public override string ToString()
        {
            string instrumentStatus;

            if (this.IsBroken)
		    {
		        instrumentStatus = "broken";
		    }
		    else
            {
                instrumentStatus = this.Wear + "%";

            }

			return $"{this.GetType().Name} [{instrumentStatus}]";
		}
	}
}
