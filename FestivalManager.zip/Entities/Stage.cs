﻿using System;

namespace FestivalManager.Entities
{
	using System.Collections.Generic;
	using Contracts;

	public class Stage : IStage
	{
		private readonly List<ISet> sets;
		private readonly List<ISong> songs;
		private readonly List<IPerformer> performers;

        public Stage()
        {
            this.sets = new List<ISet>();
            this.songs = new List<ISong>();
            this.performers = new List<IPerformer>();
        }

	    public IReadOnlyCollection<ISet> Sets => this.sets;
	    public IReadOnlyCollection<ISong> Songs => this.songs;
	    public IReadOnlyCollection<IPerformer> Performers => this.performers;

	    public IPerformer GetPerformer(string name)
	    {
	        if (!this.HasPerformer(name))
	        {
	            throw new Exception($"There is no performer with name - {name}");
	        }

	        foreach (var performer in this.Performers)
	        {
	            if (performer.Name == name)
	            {
	                return performer;
	            }
	        }

	        return null;

	    }

	    public ISong GetSong(string name)
	    {
	        if (!this.HasSong((name)))
	        {
	            throw new Exception($"There is no song with name - {name}");
	        }

	        foreach (var song in this.Songs)
	        {
	            if (song.Name == name)
	            {
	                return song;
	            }
	        }

	        return null;
	    }

	    public ISet GetSet(string name)
	    {
	        if (!this.HasSet(name))
	        {
	            throw new Exception($"There is no set with name - {name}");
	        }

	        foreach (var set in this.Sets)
	        {
	            if (set.Name == name)
	            {
	                return set;
	            }
	        }

	        return null;
	    }

	    public void AddPerformer(IPerformer performer)
	    {
	        this.performers.Add(performer);
	    }

	    public void AddSong(ISong song)
	    {
	        this.songs.Add(song);
	    }

	    public void AddSet(ISet set)
	    {
	        this.sets.Add(set);
	    }

	    public bool HasPerformer(string name)
	    {
	        foreach (var performer in this.Performers)
	        {
	            if (performer.Name == name)
	            {
	                return true;
	            }
	        }

	        return false;
	    }

	    public bool HasSong(string name)
	    {
	        foreach (var song in this.Songs)
	        {
	            if (song.Name == name)
	            {
	                return true;
	            }
	        }

	        return false;
	    }

	    public bool HasSet(string name)
	    {
	        foreach (var set in this.Sets)
	        {
	            if (set.Name == name)
	            {
	                return true;
	            }
	        }

	        return false;
	    }
	}
}
