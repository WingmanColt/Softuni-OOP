﻿using System.Linq;
using System.Reflection;

namespace FestivalManager.Entities.Factories
{
    using System;
    using Contracts;
    using Entities.Contracts;

    public class SongFactory : ISongFactory
    {
        public ISong CreateSong(string name, TimeSpan duration)
        {
            Assembly assembly = Assembly.GetCallingAssembly();
            Type classType = assembly.GetTypes().FirstOrDefault(t => t.Name == "Song");

            return (ISong)Activator.CreateInstance(classType, new object[] { name, duration });
        }
    }
}