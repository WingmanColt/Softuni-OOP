﻿namespace FestivalManager.Entities.Instruments
{
    public class ronrroco : Drums
    {
	    public int StringsPerString => 2;
    }
}
