﻿using System.Collections.Generic;
using System.Data;
using FestivalManager.Entities.Factories;
using FestivalManager.Entities.Factories.Contracts;

namespace FestivalManager.Core.Controllers
{
	using System;
	using System.Globalization;
	using System.Linq;
	using System.Text;
	using Contracts;
	using Entities.Contracts;

	public class FestivalController : IFestivalController
	{
		private const string TimeFormat = "mm\\:ss";
		private const string TimeFormatLong = "{0:2D}:{1:2D}";
		private const string TimeFormatThreeDimensional = "{0:3D}:{1:3D}";

		private readonly IStage stage;
	    private ISetFactory setFactory;
	    private IPerformerFactory performerFactory;
	    private IInstrumentFactory instrumentFactory;
	    private ISongFactory songFactory;


        public FestivalController(IStage stage)
		{
			this.stage = stage;
            this.setFactory = new SetFactory();
		    this.performerFactory = new PerformerFactory();
            this.instrumentFactory = new InstrumentFactory();
            this.songFactory = new SongFactory();
		}

		public string Report()
		{
			var result = string.Empty;

			var totalFestivalLength = new TimeSpan(this.stage.Sets.Sum(s => s.ActualDuration.Ticks));

		    result += "Results:" + Environment.NewLine;
			result += ($"Festival length: {int.Parse(totalFestivalLength.TotalMinutes.ToString("F0")).ToString("D2")}:{totalFestivalLength.Seconds.ToString("D2")}") + "\n";

			foreach (var set in this.stage.Sets)
			{
				result += ($"--{set.Name} ({int.Parse(set.ActualDuration.TotalMinutes.ToString("F0")).ToString("D2")}:{set.ActualDuration.Seconds.ToString("D2")}):") + "\n";

				var performersOrderedDescendingByAge = set.Performers.OrderByDescending(p => p.Age);
				foreach (var performer in performersOrderedDescendingByAge)
				{
					var instruments = string.Join(", ", performer.Instruments
						.OrderByDescending(i => i.Wear));

					result += ($"---{performer.Name} ({instruments})") + "\n";
				}

				if (!set.Songs.Any())
					result += ("--No songs played") + "\n";
				else
				{
					result += ("--Songs played:") + "\n";
					foreach (var song in set.Songs)
					{
						result += ($"----{song.Name} ({song.Duration.ToString(TimeFormat)})") + "\n";
					}
				}
			}

			return result.ToString().Trim();
		}

	    public string ProduceReport()
	    {
	        return this.Report();
	    }

	    public string RegisterSet(string[] args)
	    {
	        string name = args[0];
	        string type = args[1];

	        this.stage.AddSet(setFactory.CreateSet(name, type));

	        return $"Registered {type} set";
        }

		public string SignUpPerformer(string[] args)
		{
		    string name = args[0];
		    int age = int.Parse(args[1]);

		    var instrumenti = args.Skip(2).ToArray();

		    var instruments = instrumenti
		        .Select(i => this.instrumentFactory.CreateInstrument(i))
		        .ToArray();

            var performer = this.performerFactory.CreatePerformer(name, age);

			foreach (var instrument in instruments)
			{
				performer.AddInstrument(instrument);
			}

			this.stage.AddPerformer(performer);

			return $"Registered performer {performer.Name}";
		}

	    public string RegisterSong(string[] args)
	    {
	        string name = args[0];
	        string[] time = args[1].Split(':');
	        int seconds = int.Parse(time[1]);
	        int minutes = int.Parse(time[0]);
	        TimeSpan duration = new TimeSpan(0, 0, minutes, seconds);

	    this.stage.AddSong(this.songFactory.CreateSong(name, duration));

            return $"Registered song {this.stage.Songs.Last()}";
		}

	    public string AddSongToSet(string[] args)
	    {
	        string songName = args[0];
	        string setName = args[1];

	        if (!this.stage.HasSet(setName))
	        {
	            throw new InvalidOperationException("Invalid set provided");
	        }

	        if (!this.stage.HasSong(songName))
	        {
	            throw new InvalidOperationException("Invalid song provided");
	        }

	        ISet set = this.stage.GetSet(setName);
	        ISong song = this.stage.GetSong(songName);

            set.AddSong(song);

	        return $"Added {song} to {setName}";
	    }

	    public string SongRegistration(string[] args)
		{
			var songName = args[0];
			var setName = args[1];

			if (!this.stage.HasSet(setName))
			{
				throw new InvalidOperationException("Invalid set provided");
			}

			if (!this.stage.HasSong(songName))
			{
				throw new InvalidOperationException("Invalid song provided");
			}

			var set = this.stage.GetSet(setName);
			var song = this.stage.GetSong(songName);

			set.AddSong(song);

			return $"Added {song} to {set.Name}";
		}

		public string AddPerformerToSet(string[] args)
		{
		    var performerName = args[0];
		    var setName = args[1];

		    if (!this.stage.HasPerformer(performerName))
		    {
		        throw new InvalidOperationException("Invalid performer provided");
		    }

		    if (!this.stage.HasSet(setName))
		    {
		        throw new InvalidOperationException("Invalid set provided");
		    }

		    var performer = this.stage.GetPerformer(performerName);
		    var set = this.stage.GetSet(setName);

		    set.AddPerformer(performer);

		    return $"Added {performer.Name} to {set.Name}";
        }

		public string PerformerRegistration(string[] args)
		{
			var performerName = args[0];
			var setName = args[1];

			if (!this.stage.HasPerformer(performerName))
			{
				throw new InvalidOperationException("Invalid performer provided");
			}

			if (!this.stage.HasSet(setName))
			{
				throw new InvalidOperationException("Invalid set provided");
			}

			var performer = this.stage.GetPerformer(performerName);
			var set = this.stage.GetSet(setName);

			set.AddPerformer(performer);

			return $"Added {performer.Name} to {set.Name}";
		}

		public string RepairInstruments(string[] args)
		{
			List<IInstrument> instrumentsToRepair = this.stage.Performers
				.SelectMany(p => p.Instruments)
				.Where(i => i.Wear < 100)
				.ToList();

			foreach (var instrument in instrumentsToRepair)
			{
				instrument.Repair();
            }

			return $"Repaired {instrumentsToRepair.Count} instruments";
		}
	}
}