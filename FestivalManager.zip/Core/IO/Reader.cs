﻿using System;
using System.Collections.Generic;
using System.Text;
using FestivalManager.Core.IO.Contracts;

namespace FestivalManager.Core.IO
{
    public class Reader : IReader
    {
        public Reader()
        {
        }

        public string ReadLine()
        {
            return Console.ReadLine();
        }
    }
}
