﻿
using System;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using FestivalManager.Core.IO;
using FestivalManager.Entities.Contracts;

namespace FestivalManager.Core
{
    using System.Reflection;
    using Contracts;
    using Controllers;
    using Controllers.Contracts;
    using IO.Contracts;

    /// <summary>
    /// by g0shk0
    /// </summary>
    public class Engine : IEngine
    {
        private IReader reader;
        private IWriter writer;

        private StringBuilder sb;

        public IFestivalController festivalCоntroller;
        public ISetController setCоntroller;

        public Engine(IFestivalController festivalController, ISetController setController)
        {
            this.festivalCоntroller = festivalController;
            this.setCоntroller = setController;
            this.reader = new Reader();
            this.writer = new Writer();
        }

        public void Run()
        {
            while (true)
            {
                string input = this.reader.ReadLine();

                if (input == "END")
                {
                    break;
                }

                try
                {
                    writer.WriteLine(this.ProcessCommand(input));
                }
                catch (Exception e)
                {
                    writer.WriteLine("ERROR: " + e.Message);
                    //throw;
                }
            }

            writer.WriteLine(this.festivalCоntroller.ProduceReport());
        }

        public string ProcessCommand(string input)
        {
            string[] args = input.Split();
            string command = args[0];

            switch (command)
            {
                case "RegisterSet":
                    return this.festivalCоntroller.RegisterSet(args.Skip(1).ToArray());
                    break;
                case "SignUpPerformer":
                    return this.festivalCоntroller.SignUpPerformer(args.Skip(1).ToArray());
                    break;
                case "RegisterSong":
                    return this.festivalCоntroller.RegisterSong(args.Skip(1).ToArray());
                    break;
                case "AddSongToSet":
                    return this.festivalCоntroller.AddSongToSet(args.Skip(1).ToArray());
                    break;
                case "AddPerformerToSet":
                    return this.festivalCоntroller.AddPerformerToSet(args.Skip(1).ToArray());
                    break;
                case "RepairInstruments":
                    return this.festivalCоntroller.RepairInstruments(args);
                    break;
                case "LetsRock":
                    return this.setCоntroller.PerformSets();
                    break;
            }

            return null;
        }
    }
}