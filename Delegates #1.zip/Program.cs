﻿using System;

namespace Projects
{
    class Program
    {

        // This is same as
        public delegate void DelegateToPrint(string stringToPrint);
        // That..
        Action<string> actionToPrint = PrintConsole1;
        // End
        
        static void Main(string[] args)
        {

            Console.WriteLine("Hello World! 1");
            


            DelegateToPrint functionToPrint = PrintToConsole;
            functionToPrint("Hello World! 2");



            PrintStringByFunction(PrintToConsole, "Hello World! 3");


            Console.WriteLine();

           DelegateToPrint delegateToPrint = PrintConsole1;
           delegateToPrint += PrintConsole2;
           delegateToPrint("Hello World!");
        }



        private static void PrintToConsole(string stringToPrint)
        {
            Console.WriteLine(stringToPrint);
        }

        private static void PrintStringByFunction(DelegateToPrint delegateToPrint, string stringToPrint)
        {
            delegateToPrint(stringToPrint);
        }
        





        private static void PrintConsole1(string stringToPrint)
        {
            PrintToConsole($"1: {stringToPrint}");
        }

        private static void PrintConsole2(string stringToPrint)
        {
            PrintToConsole($"2: {stringToPrint}");
        }
    }
}
