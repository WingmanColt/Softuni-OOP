﻿namespace FestivalManager.Entities.Instruments
{
    public class Bongo : Drums
    {
    }
}
