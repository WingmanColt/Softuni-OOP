﻿namespace FestivalManager.Core.Controllers.Contracts
{
	public interface ISetController
	{
		string PerformSets();
	}
}